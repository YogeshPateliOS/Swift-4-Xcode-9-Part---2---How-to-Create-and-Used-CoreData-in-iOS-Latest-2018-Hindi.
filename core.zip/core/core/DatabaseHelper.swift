//
//  DatabaseHelper.swift
//  core
//
//  Created by Yogesh Patel on 26/04/18.
//  Copyright © 2018 Yogesh Patel. All rights reserved.
//

import Foundation
import CoreData
import UIKit

class DatabaseHelper{
    
    static let shareInstance = DatabaseHelper()
    let context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
    
    func save(object:[String:String]){
        let entityName = NSEntityDescription.insertNewObject(forEntityName: "Student", into: context) as! Student
        entityName.name = object["name"]
        entityName.city = object["city"]
        do{
            try context.save()
        }catch{
            print("Data not save")
        }
        
    }
    func getAllData() -> [Student]{
        var student:[Student] = []
        let fetchRequest = NSFetchRequest<NSManagedObject>(entityName: "Student")
        do{
            student = try context.fetch(fetchRequest) as! [Student]
        }catch{
            print("Not get data")
        }
        return student
    }
}
